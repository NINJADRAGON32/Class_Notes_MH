#matthew Howard

#gathering user inputs
num1 = float(input("enter your first number: "))
num2 =float(input("enter your second number: "))
operator = str(input("input the operator pls: "))
#if statment for the operator and their funcrions
if operator =="+":
    print(num1+num2)
elif operator =="-":
    print(num1-num2)
elif operator =="/":
    print(num1/num2)
elif operator == "*":
    print(num1*num2)
elif operator =="**":
    print(num1**num2)
