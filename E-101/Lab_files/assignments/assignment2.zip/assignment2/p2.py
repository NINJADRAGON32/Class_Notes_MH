#user input
ui = str(input("enter your sentence: "))
# reverse and capitalize the sentence
reverse = ui[::-1]
reverse = reverse.upper()
print(reverse)