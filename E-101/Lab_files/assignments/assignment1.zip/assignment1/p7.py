speed = float(input("enter the speed: "))
speed =speed *0.621371
print (speed)