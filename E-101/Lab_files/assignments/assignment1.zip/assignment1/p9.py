temp = float(input("Enter the temp: "))
temp = (temp * (9/5))+32
print(temp)