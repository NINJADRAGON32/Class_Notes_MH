weight = float(input("enter the weight: "))
weight = weight*2.205
print(weight)